import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Header from "./components/Header/Header";
import Homepage from "./components/Homepage/Homepage";
import Vision from "./components/Vision/Vision";
import Mission from "./components/Mission/Mission";
import Manifesto from "./components/Manifesto/Manifesto";

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <Routes>
        <Route path="/" element={<Homepage/>} /> 
        <Route path="/vision" element={<Vision />} />
        <Route path="/mission" element={<Mission />} />
        <Route path="/manifesto" element={<Manifesto />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
