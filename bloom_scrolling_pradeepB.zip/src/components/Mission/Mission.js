import React, { useState } from 'react';
import Styles from './mission.module.css';

export default function Mission() {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const missionData = {
    title: "Our Mission",
    description: `At Bloom, our mission is to empower individuals and organizations to create innovative solutions that drive positive social, environmental, and economic change.`,
    sections: [
      {
        title: "Empowering Communities",
        content: `We believe that communities hold the key to sustainable change. By providing access to education, resources, and technology, we aim to build local capacity and create self-sustaining communities.`,
      },
      {
        title: "Driving Innovation",
        content: `Innovation is the engine of progress. We are dedicated to supporting the creation of new technologies, business models, and social enterprises that address critical global challenges.`,
      },
      {
        title: "Building Sustainability",
        content: `Sustainability is at the core of everything we do. Our mission is to reduce the environmental footprint of individuals and organizations while promoting regenerative practices.`,
      },
    ],
    callToAction: {
      title: "Join Us in Creating a Better Future",
      description: `Our mission is ambitious, but we can’t do it alone. We invite you to become a part of this global movement.`,
    },
  };

  return (
    <section id="mission" className={Styles.missionSection}>
      <div className={Styles.missionContent}>
        <h2 className={Styles.sectionTitle}>{missionData.title}</h2>
        <p className={Styles.description}>{missionData.description}</p>

        <div className={Styles.accordionContainer}>
          {missionData.sections.map((section, index) => (
            <div key={index} className={Styles.accordionItem}>
              <div
                className={Styles.accordionHeader}
                onClick={() => toggleAccordion(index)}
              >
                <h3>{section.title}</h3>
              </div>
              {activeIndex === index && (
                <div className={Styles.accordionContent}>
                  <p>{section.content}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className={Styles.callToAction}>
          <h3>{missionData.callToAction.title}</h3>
          <p>{missionData.callToAction.description}</p>
        </div>
      </div>
    </section>
  );
}
