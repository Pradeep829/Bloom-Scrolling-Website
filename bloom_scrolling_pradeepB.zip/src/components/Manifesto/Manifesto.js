import React from 'react';
import Styles from './manifesto.module.css';

export default function Manifesto() {
  const manifestoData = {
    title: "Our Manifesto",
    description: `At Bloom, we believe that together we can make a significant impact. Our manifesto outlines the core values that we uphold in our quest to inspire change, innovate for the future, and advocate for a sustainable tomorrow.`,
    sections: [
      {
        title: "Freedom and Equality",
        content: `We envision a world where freedom and equality are not just ideals but tangible realities. We believe in equal access to resources, opportunities, and the power of collective freedom.`,
      },
      {
        title: "Sustainability for All",
        content: `Sustainability is not a choice; it’s a necessity. We aim to promote responsible consumption, clean energy, and eco-friendly practices to protect the Earth for generations to come.`,
      },
      {
        title: "Innovation and Creativity",
        content: `Creativity is the catalyst for change. We encourage new ideas, bold solutions, and creative minds working together to solve complex global issues.`,
      },
      {
        title: "Global Collective Action",
        content: `Through collaboration, we can solve the world’s most pressing problems. We advocate for unity across borders, cultures, and industries to create impactful solutions that benefit everyone.`,
      },
    ],
    callToAction: {
      title: "Join Us in the Manifesto for Change",
      description: `Our manifesto is a call to action. We invite you to join our cause, align with our values, and become part of a movement that is reshaping the future.`,
    },
  };

  return (
    <section id="manifesto" className={Styles.manifestoSection}>
      <div className={Styles.manifestoContent}>
        <div className={Styles.headerContainer}>
          <h2 className={Styles.sectionTitle}>{manifestoData.title}</h2>
          <p className={Styles.description}>{manifestoData.description}</p>
        </div>

        <div className={Styles.cardsContainer}>
          {manifestoData.sections.map((section, index) => (
            <div key={index} className={Styles.card}>
              <div className={Styles.cardHeader}>
                <h3>{section.title}</h3>
              </div>
              <div className={Styles.cardBody}>
                <p>{section.content}</p>
              </div>
            </div>
          ))}
        </div>

        <div className={Styles.callToAction}>
          <h3>{manifestoData.callToAction.title}</h3>
          <p>{manifestoData.callToAction.description}</p>
        </div>
      </div>
    </section>
  );
}
