import React from 'react';
import Styles from './homepage.module.css';

// A component for the custom volume-like scrollbar
function CustomScrollbar({ activeLine }) {
  return (
    <div className={Styles.custom_scrollbar}>
      {[...Array(7)].map((_, index) => (
        <div
          key={index}
          className={`${Styles.scrollbar_line} ${activeLine === index + 1 ? Styles.active : ''}`}
        />
      ))}
    </div>
  );
}

export default CustomScrollbar;
