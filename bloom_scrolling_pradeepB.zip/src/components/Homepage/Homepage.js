import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate hook
import Styles from "./homepage.module.css";
import catalyst from "../../assets/img/catalyst.jpg"

import governance from "../../assets/img/governance.png"

function Homepage() {
  const navigate = useNavigate(); 

  // Your homepage_data object 
  const homepage_data = { 
    title: "Welcome to Bloom",
    description:
      "A digital space designed to help people feel more connected, inspired, and aligned in their daily lives.",
    section2_title: "Catalyst",
    section2_description:
      "“Social media” is a broken term, loaded with negative connotations. Empty, corrupted media and content has taken over our lives.",
    section3_title: "The Potential to Move Toward Liquid Governance",
    section3_description:
      "This design could intentionally advance toward a liquid democracy or meritocracy platform by emphasizing shared purpose, relationality, and meaningful engagement.",
    section4_title: "Core Synergies",
    section4: [
      {
        id: 1,
        heading: "Relational Empowerment",
        description:
          " Features like Orbits and Ripple Effects emphasize human connection, forming a relational foundation essential for a liquid democracy. ",
      },
      {
        id: 2,
        heading: "Transparency and Collective Impact",
        description:
          "The Bloomsphere visualizes collective outcomes, akin to tracking how policies and decisions ripple through a liquid democracy system",
      },
      {
        id: 3,
        heading: "Incentive Alignment",
        description:
          "Bloomscore motivates positive contributions, mirroring how liquid democracy rewards participation and thoughtful delegation.",
      },
      {
        id: 4,
        heading: "Decentralized Communities",
        description:
          "Orbits act as dynamic hubs where users collaborate, debate, and co-create solutions, similar to local nodes in a liquid democracy framework.",
      },
    ],
    section5_title: "Practical Implementation",
    section5: [
      {
        id: 1,
        title: "Growth Journeys as Citizen Education",
        description:
          "Topic-based feeds can educate users on key issues, helping them make informed votes or delegate their voice effectively.",
      },
      {
        id: 2,
        title: "Sparks for Civic Engagement",
        description:
          " Personalized prompts can encourage users to participate in democratic processes, whether by voting, delegating, or contributing to discussions.",
      },
      {
        id: 3,
        title: "Mindful Pause for Reflective Democracy:",
        description:
          "Encourages thoughtful participation over impulsive reactions, ensuring decisions reflect deliberation rather than fleeting trends.",
      },
      {
        id: 4,
        title: "Ripple Effects to Demonstrate Civic Impact",
        description:
          "Tracks how individual and collective actions contribute to larger societal goals, motivating deeper engagement and trust in the system.",
      },
    ],
    section6_title: "Strengthening Liquid Governance",
    section6: [
      {
        id: 1,
        title: "Data Privacy and Trust",
        description:
          "Bloom’s focus on privacy design builds the confidence needed for secure and transparent decision-making in a democratic platform.",
      },
      {
        id: 2,
        title: "Blind Spot Exposure",
        description:
          "By highlighting underrepresented perspectives, the platform can correct biases, ensuring equitable representation in a liquid democracy.",
      },
      {
        id: 3,
        title: "Evolutionary Roadmap",
        description:
          "Bloom’s phases (germination to senescence) mirror the adaptability required for a liquid democracy to evolve with its community.",
      },
    ],
    section7_title: "Collaborative Opportunities",
    section7: [
      {
        id: 1,
        title: "Leveraging Bloom’s Network",
        description:
          "Partnerships with organizations like the Society Library and the Center for Humane Technology could provide frameworks for informed debate, while collaborations with ethical tech initiatives ensure robust and secure platforms.",
      },
      {
        id: 2,
        title: "Cultural Alignment",
        description:
          "Advisors like Tristan Harris and Aza Raskin can help design algorithms that prioritize civic engagement and counteract attention exploitation.",
      },
    ],


  };

  // Function to handle button click and navigate to Vision page
  const navigateToVision = () => {
    navigate("/vision");
  };

  // Refs for each section
  const section1Ref = useRef(null); 
  const section2Ref = useRef(null);
  const section3Ref = useRef(null);
  const section4Ref = useRef(null);
  const section5Ref = useRef(null);
  const section6Ref = useRef(null);
  const section7Ref = useRef(null);

  // State to track the active section ID
  const [activeSectionId, setActiveSectionId] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSectionId(entry.target.id);
          }
        });
      },
      {
        root: null,
        rootMargin: "0px",
        threshold: 0.5, // Adjust threshold as needed
      }
    );

    // Observe each section
    observer.observe(section1Ref.current);

    observer.observe(section2Ref.current);
    observer.observe(section3Ref.current);
    observer.observe(section4Ref.current);
    observer.observe(section5Ref.current);
    observer.observe(section6Ref.current);
    observer.observe(section7Ref.current);

    return () => observer.disconnect();
  }, []); 



  return (
    <div className={Styles.homepage}>
      <div className={Styles.homepage_container}>
        
        <div className={`${Styles.homepage_wrapper} ${
          activeSectionId === "section1" ? Styles.section1_active : "" 
        }`} 
        ref={section1Ref} 
        id="section1" >
          <h1 className={Styles.bloom_title}>{homepage_data.title}</h1>
          <div className={Styles.bloom_description}>
            {homepage_data.description}
          </div>
          {/* Vision Button, now using navigate */}
          <button onClick={navigateToVision} className={Styles.vision_btn}>
            Vision
          </button>
        </div>
      </div>

      {/* section 2 */}
      <div
        className={`${Styles.section2_wrapper} ${
          activeSectionId === "section2" ? Styles.active : ""
        }`}
        ref={section2Ref}
        id="section2"
      >
        <div className={Styles.section2_description_wrapper}>
          <div className={Styles.section2_title}>
            {homepage_data.section2_title}
          </div>
          <div className={Styles.section2_description}>
            {homepage_data.section2_description}
          </div>
        </div>
        <div className={Styles.section2_img_wrapper}>
          <img alt="" className={Styles.section2_img} src={catalyst}/>
        </div>
      </div>

      {/* section 3 */}
      <div
        className={`${Styles.section3_wrapper} ${
          activeSectionId === "section3" ? Styles.active : ""
        }`}
        ref={section3Ref}
        id="section3"
      >
        <div className={Styles.section3_title}>
          {homepage_data.section3_title}
        </div>
        <div className={Styles.section3_description}>
          {homepage_data.section3_description}
        </div>
        <div className={Styles.section3_img_wrapper}>
          <img alt="" className={Styles.section3_img} src={governance}/>
        </div>
      </div>

      {/* section 4 */}
      <div
        className={`${Styles.section4_wrapper} ${
          activeSectionId === "section4" ? Styles.active : ""
        }`}
        ref={section4Ref}
        id="section4"
      >
        <div className={Styles.section4_title}>
          {homepage_data.section4_title}
        </div>
        <div className={Styles.section4_content}>
          {homepage_data &&
            homepage_data.section4 &&
            homepage_data.section4.map((item, id) => (
              <div key={id} className={Styles.section4_card}>
                <div className={Styles.section4_heading}>{item.heading}</div>
                <div className={Styles.section4_description}>
                  {item.description}
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Section 5 */}
      <div
        className={`${Styles.section5} ${
          activeSectionId === "section5" ? Styles.active : ""
        }`}
        ref={section5Ref}
        id="section5">
        <div className={Styles.section5_title}>
          {homepage_data.section5_title}
        </div>
        <div className={Styles.section5_flex_wrapper}>
          {homepage_data.section5.map((item) => (
            <div key={item.id} className={Styles.section5_card}>
              <div className={Styles.section5_heading}>{item.title}</div>
              <div className={Styles.section5_description}>
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* section 6 */}
      <div
        className={`${Styles.section6} ${
          activeSectionId === "section6" ? Styles.active : ""
        }`}
        ref={section6Ref}
        id="section6"
      >
        <div className={Styles.section6_title}>
          {homepage_data.section6_title}
        </div>
        <div className={Styles.section6_flex_wrapper}>
          {homepage_data.section6.map((item) => (
            <div key={item.id} className={Styles.section6_card}>
              <div className={Styles.section6_heading}>{item.title}</div>
              <div className={Styles.section6_description}>
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* section 7 */}
      <div
        className={`${Styles.section7} ${
          activeSectionId === "section7" ? Styles.active : ""
        }`}
        ref={section7Ref}
        id="section7"
      >
        <div className={Styles.section7_title}>
          {homepage_data.section7_title}
        </div>
        <div className={Styles.section7_flex_wrapper}>
          {homepage_data.section7.map((item) => (
            <div key={item.id} className={Styles.section7_card}>
              <div className={Styles.section7_heading}>{item.title}</div>
              <div className={Styles.section7_description}>
                {item.description}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className={Styles.custom_scrollbar}>
      <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section1" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section2" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section3" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section4" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section5" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section6" ? Styles.scrollbar_active : ""}`}
          >
          </div>
          <div
            className={`${Styles.scrollbar_underline} ${activeSectionId === "section7" ? Styles.scrollbar_active : ""}`}
          >
          </div>
      </div>
    </div>
  );
}

export default Homepage;