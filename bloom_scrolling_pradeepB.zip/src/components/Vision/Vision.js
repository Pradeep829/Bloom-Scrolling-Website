import React from "react";
import Styles from "./vision.module.css";

export default function Vision() {
  // Expanded data with more detailed descriptions
  const visionData = {
    title: "Our Vision",
    description: `At Bloom, we are driven by the belief that creativity, sustainability, and innovation can create a better tomorrow. Our vision is more than just words — it’s a commitment to a world where we are empowered to make transformative changes that can shape a brighter future. As we move forward, we focus on creating tangible impact through collective action and positive change, one step at a time.`,
    sections: [
      {
        title: "Sustainability",
        content: `Sustainability is a core pillar of our philosophy. Our planet’s resources are finite, and we recognize the urgent need for sustainable practices in every aspect of our daily lives.`,
      },
      {
        title: "Creativity",
        content: `Creativity is not just about producing art; Bloom, we believe that creative minds can reshape the world. We encourage out-of-the-box thinking and foster environments where unconventional ideas can thrive.`,
      },
      {
        title: "Community",
        content: `True progress can only be achieved when people come together as a unified force. We focus on creating ecosystems that empower individuals, foster collaboration, and promote equality. `,
      },
      {
        title: "Empowerment",
        content: `Empowerment is the cornerstone of social change. At Bloom, we are committed to empowering individuals by providing them with the resources, skills, and opportunities needed to succeed. `,
      },
    ],
    callToAction: {
      title: "Join Us in Blooming the Future",
      description: `At Bloom, we believe that together, we can create a future where every individual has the opportunity to thrive. We invite you to be a part of this transformative journey. Whether through collaboration, advocacy, or simply spreading the word, your involvement can make a real difference. Let’s work together to create a world that is more creative, sustainable, inclusive, and empowered. With your help, we can achieve a lasting, positive impact for generations to come.`,
      furtherMessage: `Every step we take today shapes the future we’ll live in tomorrow. This vision is a collective effort, and we need passionate individuals, organizations, and communities to help bring it to fruition. Whether you want to volunteer, partner with us, or donate, there’s a place for you in this journey. Together, we can make a world of difference. Join us, and let’s bloom the future together!`,
    },
  };

  return (
    <section id="vision" className={Styles.visionSection}>
      <div className={Styles.visionContent}>
        <h2 className={Styles.sectionTitle}>{visionData.title}</h2>
        <p className={Styles.description}>{visionData.description}</p>

        <div className={Styles.gridContainer}>
          {visionData.sections.map((section, index) => (
            <div key={index} className={Styles.card}>
              <h3>{section.title}</h3>
              <p>{section.content}</p>
              <p>{section.additionalContent}</p>
              <p>{section.furtherDetails}</p>
            </div>
          ))}
        </div>

        <div className={Styles.callToAction}>
          <h3>{visionData.callToAction.title}</h3>
          <p>{visionData.callToAction.description}</p>
          <p>{visionData.callToAction.furtherMessage}</p>
        </div>
      </div>
    </section>
  );
}
