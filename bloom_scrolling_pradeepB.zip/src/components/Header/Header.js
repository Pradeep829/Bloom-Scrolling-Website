import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Styles from './header.module.css';
import { ReactComponent as Hamburger } from "../../assets/svg/general/navigation.svg";
import CloseIcon from "../../assets/img/close_icon.png"

export default function Header() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false); // State for modal visibility
  
  const navigation_list = [
    { id: 1, list: 'Vision', path: '/vision' },
    { id: 2, list: 'Mission', path: '/mission' },
    { id: 3, list: 'Manifesto', path: '/manifesto' },
  ];

  const handleClick = (id) => {
    setSelected(id);
    setIsModalOpen(false); // Close modal when a link is clicked
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen); // Toggle modal visibility
  };
  const closeModal = () => {
    setIsModalOpen(false); // Close modal explicitly when the close icon is clicked
  };
  const navigation_list_card = navigation_list.map((item) => (
    <li
      key={item.id}
      className={`${Styles.list_tag} ${selected === item.id ? Styles.selected : ''}`}
    >
      <Link to={item.path} onClick={() => handleClick(item.id)}>
        {item.list}
      </Link>
    </li>
  ));

  return (
    <header className={Styles.header}>
      {/* Desktop Header */}
      <div className={Styles.header_wrapper}>
        <p
          className={Styles.bloom}
          onClick={() => {
            navigate('/');
            setSelected(null);
          }}
        >
          Bloom
        </p>
        <ul className={Styles.header_list}>{navigation_list_card}</ul>
      </div>

      {/* Mobile Header */}
      <div className={Styles.header_wrapper_mobile}>
        <p
          className={Styles.bloom}
          onClick={() => {
            navigate('/');
            setSelected(null);
          }}
        >
          Bloom
        </p>
        
        {/* Hamburger Icon */}
        <Hamburger className={Styles.hamburger} onClick={toggleModal} />

        {/* Hamburger Modal */}
        {isModalOpen && (
          <div className={Styles.hamburger_modal}>
            <div className={Styles.hamburger_wrapper}>
              <div className={Styles.close_icon_wrapper} onClick={closeModal}><img alt='' src={CloseIcon} className={Styles.close_icon}/></div>
            </div>
            <ul className={Styles.header_list}>{navigation_list_card}</ul>
          </div>
        )}
      </div>
    </header>
  );
}
